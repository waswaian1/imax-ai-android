# IMAX AI Android APK project

## Build
This project builds an Android APK with Buildozer. Upload the folder contents to a GitHub repository, open **Actions**, run **Build Android APK**, then download the `imax-ai-apk` artifact from the completed workflow. The APK can be installed on Android (allow installation from the source when prompted).

Local Linux build:
```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip build-essential autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo6 cmake libffi-dev libssl-dev
pip install --upgrade pip setuptools wheel
pip install buildozer cython==0.29.36
buildozer android debug
```

## Included
- Account name and balance
- Static / Trailing / Unknown drawdown dropdown
- Maximum and daily drawdown fields
- Protected buffer
- Planned trade slots and per-trade risk cap
- Dynamic next-trade risk calculation
- Local trade history

## Important limitations
This is a first Android MVP. It saves data locally on the device and does not yet include multi-user cloud accounts, cloud sync, a live MT5 connection, or automatic broker data. Sharing the APK gives each recipient their own local copy; it does not sync data between users. Trailing floor is an estimate (`highest equity - max drawdown`); firms may calculate it differently. Unknown mode deliberately does not calculate a breach floor. Wins use a trade slot but do not automatically raise the risk cap. Verify official firm rules and account currency before trading. Never enter broker passwords.
