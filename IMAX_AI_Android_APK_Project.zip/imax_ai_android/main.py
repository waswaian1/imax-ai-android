from app.main import IMAXAIApp
IMAXAIApp().run()
